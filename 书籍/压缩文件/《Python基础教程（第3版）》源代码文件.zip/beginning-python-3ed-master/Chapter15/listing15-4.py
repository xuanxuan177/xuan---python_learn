#!/usr/bin/env python

print('Content-type: text/plain')
print() # Prints an empty line, to end the headers

print('Hello, world!')