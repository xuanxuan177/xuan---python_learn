
Underneath this `py3` directory is a folder for each chapter of the
recent Third Edition of *Foundations of Python Network Programming* from
Apress.  To learn more, move one level up in this directory tree to read
the [Table of Contents](https://github.com/brandon-rhodes/fopnp).
