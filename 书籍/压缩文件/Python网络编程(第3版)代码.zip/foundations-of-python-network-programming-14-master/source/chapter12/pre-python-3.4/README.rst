
=====================================
 Chapter 12 scripts for Python <=3.3
=====================================

This directory contains the e-mail message builder scripts from the
second edition of Foundations of Python Network Programming, updated for
Python 3 but otherwise unchanged.  They should work with Python 3.3 or
even earlier versions, in case you have not yet upgraded to Python 3.4
and therefore cannot use the new API illustrated in the official
``chapter12`` directory.
